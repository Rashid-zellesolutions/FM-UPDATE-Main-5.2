import React from 'react'
import './DownloadsTab.css';

const DownloadsTab = () => {
  return (
    <div>
      Downloads Tab
    </div>
  )
}

export default DownloadsTab
